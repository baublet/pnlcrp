<?php /* $Id: configure_help.php 10669 2005-06-30 11:17:13Z jenst $ */ ?>
<?php echo sprintf(_("If you experience problems, you can find help on the %sGallery Help Page%s."),
'<a href="http://gallery.sourceforge.net/help.php">', '</a>') ?>
