<?php /* $Id: php_value_ok.php 3374 2003-07-28 09:49:27Z jefmcg $ */ ?>
<?php
// If we include this file it means that the php_value directive in .htaccess 
// was obeyed.
$GALLERY_PHP_VALUE_OK = 1;
?>