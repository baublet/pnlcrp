<?php
        require (dirname(dirname(__FILE__)) . '/init.php');
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Gallery Context Help</title>
<?php 
     echo getStyleSheetLink();
    ?>
</head>
<body>
<a name="top"></a>
 
  
   <span style="font-size: 13px; font-weight: bold"><a name="test.bleh">Hello</a></span>
    
    <p>
     <em>Test</em> Hi!
    </p>
  
 
</body>
</html>
