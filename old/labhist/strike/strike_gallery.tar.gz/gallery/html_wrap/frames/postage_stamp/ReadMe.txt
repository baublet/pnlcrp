$Id: ReadMe.txt 15408 2006-12-08 02:05:13Z ckdake $

put this directory in your html_wrap/frames directory.
to enable this frame, you can do it either from the 'properties' admin    
option for a specific album, or globally using the config wizard.
after that, you can delete this file. or print it out and keep it forever.
either way is fine by me.

http://demonhood.com/addon/

-demonhood-
