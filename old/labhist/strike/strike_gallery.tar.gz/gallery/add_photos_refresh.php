<?php
/**
* $Id: add_photos_refresh.php 13579 2006-05-02 09:59:13Z jenst $
*/
?>
<html>
<head>
<title>Refresh</title>
</head>
<body onLoad="parent.opener.hideProgressAndReload(); window.close();">
<!-- This is a hack that's needed for the GR applet to be able to
refresh the album page after a successful upload... -->
</body>
</html>